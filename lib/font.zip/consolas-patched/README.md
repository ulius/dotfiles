source:
http://enegue.com/your-typing-style-and-vim/
https://github.com/eugeneching/consolasPowerlineVim
